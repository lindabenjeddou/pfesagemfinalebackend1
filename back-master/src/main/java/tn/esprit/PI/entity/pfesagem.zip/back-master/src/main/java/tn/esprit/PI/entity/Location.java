package tn.esprit.PI.entity;

public enum Location {
    CMS2,
    INTEGRATION;

}
