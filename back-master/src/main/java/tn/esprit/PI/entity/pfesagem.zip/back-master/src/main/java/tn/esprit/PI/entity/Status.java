package tn.esprit.PI.entity;



public enum Status {
    IN_TRANSIT,
    DELIVERED,
    OUT_FOR_DELIVERY,
    DELAYED,
    RETURNED_TO_SENDER,
    OUT_FOR_PICKUP
}