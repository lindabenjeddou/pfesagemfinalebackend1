package tn.esprit.PI.entity;

public enum PlanningStatus {
    IN_PROGRESS,
    COMPLETED,
    PENDING,
    CANCELLED;
}
