package tn.esprit.PI.RestControlleur;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tn.esprit.PI.Services.DemandeInterventionService;
import tn.esprit.PI.Services.BonDeTravailService;
import tn.esprit.PI.entity.*;
import tn.esprit.PI.repository.DemandeInterventionRepository;
import tn.esprit.PI.repository.UserRepository;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/demandes")
public class DemandeInterventionController {

    @Autowired
    private DemandeInterventionService demandeInterventionService;

    @Autowired
    private DemandeInterventionRepository demandeInterventionRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BonDeTravailService bonDeTravailService;

    /** ★ Interventions assignées à un technicien (DTO) */
    @GetMapping("/technicien/{techId}")
    public ResponseEntity<List<DemandeInterventionDTO>> getByTechnicien(@PathVariable Long techId) {
        return ResponseEntity.ok(demandeInterventionService.getByTechnicien(techId));
    }

    @PostMapping("/create")
    public ResponseEntity<?> createIntervention(@RequestBody Map<String, Object> requestData) {
        try {
            String typeDemande = (String) requestData.get("type_demande");
            if (typeDemande == null) typeDemande = (String) requestData.get("type");
            if (typeDemande == null) typeDemande = (String) requestData.get("typeDemande");
            if (typeDemande != null) typeDemande = typeDemande.toUpperCase().trim();

            Long demandeurId = ((Number) requestData.get("demandeurId")).longValue();
            User demandeur = userRepository.findById(demandeurId)
                    .orElseThrow(() -> new RuntimeException("Demandeur non trouvé"));

            String description = (String) requestData.get("description");
            String priorite = (String) requestData.get("priorite");
            Date dateDemande = new Date();

            String statutStr = (String) requestData.get("statut");
            StatutDemande statut = StatutDemande.valueOf(statutStr.toUpperCase());

            if ("CURATIVE".equals(typeDemande) || "CORRECTIVE".equals(typeDemande)) {
                Curative curative = new Curative();
                curative.setDescription(description);
                curative.setDateDemande(dateDemande);
                curative.setStatut(statut);
                curative.setPriorite(priorite);
                curative.setDemandeur(demandeur);
                curative.setPanne((String) requestData.get("panne"));
                curative.setUrgence((Boolean) requestData.get("urgence"));
                return ResponseEntity.ok(demandeInterventionRepository.save(curative));
            } else if ("PREVENTIVE".equals(typeDemande)) {
                Preventive preventive = new Preventive();
                preventive.setDescription(description);
                preventive.setDateDemande(dateDemande);
                preventive.setStatut(statut);
                preventive.setPriorite(priorite);
                preventive.setDemandeur(demandeur);
                preventive.setFrequence((String) requestData.get("frequence"));
                preventive.setProchainRDV(new SimpleDateFormat("yyyy-MM-dd").parse((String) requestData.get("prochainRDV")));
                return ResponseEntity.ok(demandeInterventionRepository.save(preventive));
            } else {
                return ResponseEntity.badRequest()
                        .body("Type de demande non pris en charge. (CURATIVE / CORRECTIVE / PREVENTIVE)");
            }

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erreur lors de la création: " + e.getMessage());
        }
    }

    @GetMapping("/recuperer/{id}")
    public ResponseEntity<DemandeInterventionDTO> getDemandeById(@PathVariable Long id) {
        Optional<DemandeInterventionDTO> demande = demandeInterventionService.getDemandeById(id);
        return demande.map(response -> new ResponseEntity<>(response, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/recuperer/all")
    public ResponseEntity<List<DemandeInterventionDTO>> getAllDemandes() {
        List<DemandeInterventionDTO> demandes = demandeInterventionService.getAllDemandes();
        return new ResponseEntity<>(demandes, HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<?> getAllDemandesShort() {
        try {
            List<DemandeInterventionDTO> demandes = demandeInterventionService.getAllDemandes();
            return new ResponseEntity<>(demandes, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erreur lors de la récupération des demandes: " + e.getMessage());
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateDemande(@PathVariable Long id, @RequestBody DemandeInterventionDTO dto) {
        try {
            DemandeInterventionDTO updatedDemande = demandeInterventionService.updateDemande(id, dto);
            return new ResponseEntity<>(updatedDemande, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(Map.of(
                    "error", "Erreur lors de la mise à jour",
                    "message", e.getMessage()
            ), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(Map.of(
                    "error", "Erreur interne du serveur",
                    "message", e.getMessage()
            ), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/assign/{interventionId}/technicien/{technicienId}")
    public ResponseEntity<?> assignTechnicianToIntervention(
            @PathVariable Long interventionId,
            @PathVariable Long technicienId) {
        try {
            DemandeInterventionDTO updated = demandeInterventionService
                    .assignTechnicianToIntervention(interventionId, technicienId);
            return new ResponseEntity<>(updated, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(Map.of(
                    "error", "Erreur lors de l'affectation",
                    "message", e.getMessage()
            ), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(Map.of(
                    "error", "Erreur interne du serveur",
                    "message", e.getMessage()
            ), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/assign/{interventionId}/testeur/{testeurCodeGMAO}")
    public ResponseEntity<?> assignTesteurToIntervention(
            @PathVariable Long interventionId,
            @PathVariable String testeurCodeGMAO) {
        try {
            DemandeInterventionDTO updated = demandeInterventionService
                    .assignTesteurToIntervention(interventionId, testeurCodeGMAO);
            return new ResponseEntity<>(updated, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(Map.of(
                    "error", "Erreur lors de l'affectation du testeur",
                    "message", e.getMessage()
            ), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(Map.of(
                    "error", "Erreur interne du serveur",
                    "message", e.getMessage()
            ), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/confirmer/{interventionId}")
    public ResponseEntity<?> confirmerIntervention(@PathVariable Long interventionId) {
        try {
            DemandeInterventionDTO updated = demandeInterventionService
                    .confirmerIntervention(interventionId);
            return new ResponseEntity<>(updated, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(Map.of(
                    "error", "Erreur lors de la confirmation",
                    "message", e.getMessage()
            ), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(Map.of(
                    "error", "Erreur interne du serveur",
                    "message", e.getMessage()
            ), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /* ---- Bons de travail liés à l’intervention (si nécessaire ici) ---- */

    @PostMapping("/{interventionId}/bon-travail/technicien/{technicienId}")
    public ResponseEntity<?> createBonDeTravailForIntervention(
            @PathVariable Long interventionId,
            @PathVariable Long technicienId,
            @RequestBody BonTravailRequest request) {
        try {
            BonDeTravail bon = bonDeTravailService
                    .createBonDeTravailFromIntervention(interventionId, technicienId, request);
            return new ResponseEntity<>(bon, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(Map.of(
                    "error", "Erreur lors de la création du bon de travail",
                    "message", e.getMessage()
            ), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>(Map.of(
                    "error", "Erreur interne du serveur",
                    "message", e.getMessage()
            ), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{interventionId}/bons-travail")
    public ResponseEntity<?> getBonsDeTravailForIntervention(@PathVariable Long interventionId) {
        try {
            List<BonDeTravail> bons = bonDeTravailService.getBonsDeTravailByIntervention(interventionId);
            return new ResponseEntity<>(bons, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(Map.of(
                    "error", "Erreur lors de la récupération des bons de travail",
                    "message", e.getMessage()
            ), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
