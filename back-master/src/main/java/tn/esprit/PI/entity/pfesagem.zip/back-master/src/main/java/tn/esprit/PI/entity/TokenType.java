package tn.esprit.PI.entity;

public enum TokenType {
  BEARER
}
