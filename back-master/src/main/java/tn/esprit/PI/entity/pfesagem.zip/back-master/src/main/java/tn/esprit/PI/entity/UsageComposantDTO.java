package tn.esprit.PI.entity;

import java.math.BigDecimal;

public record UsageComposantDTO(String trartArticle, BigDecimal quantiteUtilisee) {}