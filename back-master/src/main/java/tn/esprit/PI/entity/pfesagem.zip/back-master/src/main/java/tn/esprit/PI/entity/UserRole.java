package tn.esprit.PI.entity;

public enum UserRole {
    ADMIN,
    MAGASINIER,
    CHEF_PROJET,
    TECHNICIEN_CURATIF,
    TECHNICIEN_PREVENTIF,
    CHEF_SECTEUR,
    SUPERVISEUR_PRODUCTION;
}
