package tn.esprit.PI.entity;

import java.time.LocalDateTime;

public record DebutReelDTO(LocalDateTime dateDebutReel) {}
