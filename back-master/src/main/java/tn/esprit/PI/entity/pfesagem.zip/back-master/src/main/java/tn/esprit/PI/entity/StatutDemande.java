package tn.esprit.PI.entity;

public enum StatutDemande {
    EN_ATTENTE, TERMINEE, EN_COURS
}
