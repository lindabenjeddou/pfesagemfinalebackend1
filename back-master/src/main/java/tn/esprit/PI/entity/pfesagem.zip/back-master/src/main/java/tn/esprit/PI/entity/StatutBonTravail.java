package tn.esprit.PI.entity;

public enum StatutBonTravail {
        EN_ATTENTE,
        EN_COURS,
        TERMINE
    }

