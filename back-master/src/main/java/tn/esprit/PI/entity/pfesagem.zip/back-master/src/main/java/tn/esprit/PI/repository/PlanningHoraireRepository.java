package tn.esprit.PI.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.esprit.PI.entity.PlanningHoraire;

public interface PlanningHoraireRepository extends JpaRepository<PlanningHoraire, Long> {
}
