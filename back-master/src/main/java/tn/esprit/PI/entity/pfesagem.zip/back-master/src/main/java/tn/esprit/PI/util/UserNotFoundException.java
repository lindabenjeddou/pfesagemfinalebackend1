package tn.esprit.PI.util;

public class UserNotFoundException extends RuntimeException {

    public UserNotFoundException(String message) {
        super(message);
    }

    // Other constructors or methods
}
