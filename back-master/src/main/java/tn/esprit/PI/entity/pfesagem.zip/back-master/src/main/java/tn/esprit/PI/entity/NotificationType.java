package tn.esprit.PI.entity;

public enum NotificationType {
    COMPONENT_ORDER,
    STOCK_UPDATE,
    SOUS_PROJET_CREATED,
    GENERAL
}
